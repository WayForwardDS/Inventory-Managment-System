import React, { useEffect, useState } from 'react';
import { Table, Button, Space, Input, Tag, Popconfirm } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { useGetRacksQuery } from '../redux/features/management/warehouseApt';
import { ProductInRack } from '../types/warehouse.type';

const { Search } = Input;

const StockTablePage = () => {
    const { data: racks, isLoading } = useGetRacksQuery();
    const [filteredData, setFilteredData] = useState<ProductInRack[]>([]);
    
    useEffect(() => {
      if (racks) {
        const allProducts = racks.flatMap(rack => rack.products);
        setFilteredData(allProducts);
      }
    }, [racks]);
    
    const handleSearch = (value: string) => {
      if (!racks) return;
      const allProducts = racks.flatMap(rack => rack.products);
      const filtered = allProducts.filter((item) =>
        item.name.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredData(filtered);
    };
    

  const handleDelete = async (id: string) => {
    try {
      await deleteStock(id);
      // Optionally refresh the table data or handle the UI state after delete
    } catch (err) {
      console.error('Failed to delete stock item:', err);
    }
  };

  const columns = [
    {
      title: 'Product Name',
      dataIndex: 'productName',
      key: 'productName',
      render: (text: string) => <Tag color="blue">{text}</Tag>,
    },
    {
      title: 'Barcode',
      dataIndex: 'barcode',
      key: 'barcode',
    },
    {
      title: 'Quantity',
      dataIndex: 'quantity',
      key: 'quantity',
    },
    {
      title: 'Action',
      key: 'action',
      render: (_: any, record: ProductInRack) => (
        <Space size="middle">
          <Button
            icon={<EditOutlined />}
            type="primary"
            size="small"
            // Implement your edit functionality here
          />
          <Popconfirm
            title="Are you sure to delete?"
            onConfirm={() => handleDelete(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button icon={<DeleteOutlined />} type="danger" size="small" />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="p-4">
      <h2 className="mb-4 text-xl font-semibold">Stock Table</h2>

      <div className="flex items-center justify-between mb-4">
        <Search
          placeholder="Search Product"
          allowClear
          enterButton="Search"
          onSearch={handleSearch}
          className="w-1/3"
        />
        <Button type="primary" className="ml-4">
          Add New Stock
        </Button>
      </div>

      <Table
        loading={isLoading}
        dataSource={filteredData}
        columns={columns}
        rowKey="id"
        pagination={{
          pageSize: 10,
          showQuickJumper: true,
        }}
      />
    </div>
  );
};

export default StockTablePage;
function deleteStock(id: string) {
    throw new Error('Function not implemented.');
}





// // deepseek code

// import { useLocation } from 'react-router-dom';
// import { RackCard } from '../../components/warehouse/RackCard';
// import { AddStockForm } from '../../components/warehouse/AddStockForm';
// import {ProductInRackTable} from '../../components/warehouse/ProductInRackTable';
// import { useGetRacksQuery } from '../../redux/features/management/warehouseApt';
// import { useState } from 'react';

// export const WarehouseManagementPage = () => {
//   const location = useLocation();
//   const { data: racks, isLoading } = useGetRacksQuery();
//   const [selectedRack, setSelectedRack] = useState(null);

//   if (isLoading) return <p>Loading racks...</p>;

//   const showRackScanner = location.pathname === '/warehouse-management';
//   const showStockTable = location.pathname === '/warehouse-management/stock-table';

//   return (
//     <div className="p-4">
//       {showRackScanner && (
//         <div className="flex flex-wrap gap-4">
//           {racks?.map((rack) => (
//             <RackCard key={rack.id} rack={rack} onClick={() => setSelectedRack(rack)} />
//           ))}
//         </div>
//       )}

//       {selectedRack && <AddStockForm rack={selectedRack} onClose={() => setSelectedRack(null)} />}

//       {showStockTable && <ProductInRackTable />}
//     </div>
//   );
// };

import { useState } from 'react';
import { useGetRacksQuery } from '../../redux/features/management/warehouseApt';
import { RackCard } from '../../components/warehouse/RackCard';
import { AddStockForm } from '../../components/warehouse/AddStockForm';

export const WarehouseManagementPage = () => {
  const { data: racks = [], isLoading } = useGetRacksQuery();
  const [selectedRack, setSelectedRack] = useState<{
    id: string;
    name: string;
    capacity: number;
    used: number;
  } | null>(null);
  
  if (isLoading) return <div>Loading racks...</div>;
  
  return (
    <div className="container p-4 mx-auto">
      <h1 className="mb-6 text-2xl font-bold">Warehouse Management</h1>
      
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {racks.map((rack) => (
          <RackCard
            key={rack.id}
            rack={rack}
            onClick={() => setSelectedRack(rack)}
          />
        ))}
      </div>
      
      {selectedRack && (
        <AddStockForm
          rack={selectedRack}
          onClose={() => setSelectedRack(null)}
        />
      )}
    </div>
  );
};
import { Card, Tag, Tooltip, Badge } from 'antd';
import {
  HomeOutlined,
  InboxOutlined,
  PercentageOutlined,
  EditOutlined,
} from '@ant-design/icons';
import { motion } from 'framer-motion';
import { TinyColor } from '@ctrl/tinycolor';
import { Rack } from '../../types/warehouse.type';

interface RackCardProps {
  rack: Rack;
  onClick: () => void;
}

export const RackCard = ({ rack, onClick }: RackCardProps) => {
  const percentage = Math.round((rack.used / rack.capacity) * 100);
  const statusColor =
    percentage >= 100 ? '#ff4d4f' : percentage >= 90 ? '#faad14' : '#52c41a';
  const animatedColor = new TinyColor(statusColor).lighten(8).toString();

  return (
    <motion.div
      onClick={onClick}
      className="cursor-pointer"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <Card
        bordered={false}
        className="relative transition-all shadow-md w-72 h-60 rounded-2xl bg-white/90 backdrop-blur-lg hover:shadow-xl"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <HomeOutlined className="text-gray-500" />
            <span className="text-sm font-semibold text-gray-700">{rack.name}</span>
          </div>
          <Tooltip title="Edit Rack">
            <EditOutlined className="text-sm text-blue-500 hover:text-blue-700" />
          </Tooltip>
        </div>

        <motion.div
          className="flex flex-col items-center justify-center mt-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div
            className="relative w-28 h-28 rounded-full border-[6px] flex items-center justify-center"
            style={{ borderColor: animatedColor }}
          >
            
            <span className="text-xl font-bold text-gray-700">{percentage}%</span>
          </div>
          <span className="mt-1 text-xs text-gray-500">Rack Usage</span>
        </motion.div>

        <div className="absolute space-y-1 bottom-4 left-4">
          <Tag
            icon={<PercentageOutlined />}
            color="blue"
            className="text-xs px-2 py-0.5"
          >
            {rack.capacity} units
          </Tag>
          <Tag
            color={percentage >= 100 ? 'red' : 'green'}
            className="text-xs px-2 py-0.5"
          >
            {rack.used} stored
          </Tag>
        </div>

        {percentage >= 100 && (
          <Badge.Ribbon text="FULL" color="red" className="absolute -top-1 -right-1" />
        )}
      </Card>
    </motion.div>
  );
};

import { useForm } from 'react-hook-form';
import {
  Button,
  Input,
  Slider,
  Space,
  Typography,
  Card,
  Form,
  Divider,
} from 'antd';
import {
  BarcodeOutlined,
  TagOutlined,
  NumberOutlined,
  DashboardOutlined,
  CloseOutlined,
  SaveOutlined,
  PercentageOutlined,
} from '@ant-design/icons';
import { motion } from 'framer-motion';
import { useUpdateStockMutation } from '../../redux/features/management/warehouseApt';
import { Rack } from '../../types/warehouse.type';

interface AddStockFormProps {
  rack: Rack;
  onClose: () => void;
}

interface FormValues {
  productName: string;
  barcode: string;
  quantity: number;
  manualPercentage: number;
}

export const AddStockForm = ({ rack, onClose }: AddStockFormProps) => {
  const [form] = Form.useForm();
  const [updateStock] = useUpdateStockMutation();

  const onFinish = async (values: FormValues) => {
    try {
      await updateStock({
        type: 'IN',
        productBarcode: values.barcode,
        quantity: values.quantity,
        rackId: rack.id,
        manualPercentage: values.manualPercentage,
        timestamp: new Date().toISOString(),
      }).unwrap();
      onClose();
    } catch (error) {
      console.error('Failed to update stock:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md"
    >
      {/* Animated halo effect behind the card */}
      <motion.div
        className="absolute w-[500px] h-[500px] rounded-full opacity-30 blur-3xl"
        animate={{
          scale: [1, 1.1, 1],
          rotate: [0, 360, 0],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
        }}
      />

      <motion.div
        initial={{ y: 60, opacity: 0, scale: 0.98 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ type: 'spring', stiffness: 100, damping: 10 }}
        className="relative z-10"
      >
        <Card
          className="w-full max-w-xl transition-all border shadow-xl bg-white/20 border-white/30 rounded-3xl backdrop-blur-lg"
          title={
            <Space>
              <DashboardOutlined className="text-cyan-400" />
              <Typography.Title level={4} className="!m-0 text-white drop-shadow-sm">
                {rack.name} Storage
              </Typography.Title>
            </Space>
          }
          extra={
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="text-white transition-all hover:text-red-500"
            >
              <CloseOutlined />
            </motion.button>
          }
        >
          <Form
            form={form}
            layout="vertical"
            onFinish={onFinish}
            initialValues={{
              manualPercentage: Math.round((rack.used / rack.capacity) * 100),
            }}
          >
            <Form.Item
              label={
                <Space>
                  <TagOutlined />
                  <span className="text-white/80">Product Name</span>
                </Space>
              }
              name="productName"
              rules={[{ required: true, message: 'Please input product name!' }]}
            >
              <Input size="large" placeholder="Enter product name" />
            </Form.Item>

            <Form.Item
              label={
                <Space>
                  <BarcodeOutlined />
                  <span className="text-white/80">Barcode</span>
                </Space>
              }
              name="barcode"
              rules={[{ required: true, message: 'Please input barcode!' }]}
            >
              <Input size="large" placeholder="Scan or enter barcode" />
            </Form.Item>

            <Form.Item
              label={
                <Space>
                  <NumberOutlined />
                  <span className="text-white/80">Quantity</span>
                </Space>
              }
              name="quantity"
              rules={[{ required: true, message: 'Please input quantity!' }]}
            >
              <Input type="number" size="large" min={1} />
            </Form.Item>

            <Divider orientation="left">
              <Space>
                <PercentageOutlined />
                <span className="text-white/70">Storage Adjustment</span>
              </Space>
            </Divider>

            <Form.Item name="manualPercentage">
              <Slider
                min={0}
                max={100}
                tooltip={{ formatter: (value: any) => `${value}%` }}
                trackStyle={{ backgroundColor: '#00c9ff' }}
                handleStyle={{ borderColor: '#00c9ff' }}
              />
            </Form.Item>

            <div className="flex items-center justify-between mt-6">
              <Typography.Text className="text-white/60">
                Current: {rack.used}/{rack.capacity} units
              </Typography.Text>
              <Form.Item className="!mb-0">
                <Space>
                  <Button onClick={onClose}>Cancel</Button>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      type="primary"
                      htmlType="submit"
                      icon={<SaveOutlined />}
                      className="text-white transition-all shadow-lg bg-gradient-to-br from-blue-500 to-fuchsia-600 hover:from-blue-600 hover:to-fuchsia-700"
                    >
                      Save Changes
                    </Button>
                  </motion.div>
                </Space>
              </Form.Item>
            </div>
          </Form>
        </Card>
      </motion.div>
    </motion.div>
  );
};

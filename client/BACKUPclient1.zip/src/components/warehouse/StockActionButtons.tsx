// src/components/warehouse/StockActionButton.tsx
import React from 'react';
import { Button } from 'antd';
import { ProductInRack } from '../../types/warehouse.type';

interface Props {
  product: ProductInRack;
  action: 'in' | 'out' | 'delete';
  onConfirm: () => void;
}

export const StockActionButton: React.FC<Props> = ({ product, action, onConfirm }) => {
  const labelMap = {
    in: 'Confirm Stock In',
    out: 'Confirm Stock Out',
    delete: 'Confirm Delete'
  };

  return (
    <div className="mt-2">
      <p>
        Are you sure you want to <strong>{action}</strong> product{' '}
        <strong>{product.name}</strong> (Qty: {product.quantity})?
      </p>
      <Button type="primary" danger={action === 'delete'} onClick={onConfirm}>
        {labelMap[action]}
      </Button>
    </div>
  );
};

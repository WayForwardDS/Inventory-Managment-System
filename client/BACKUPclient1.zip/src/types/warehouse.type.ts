

// export interface Rack {
//     id: string;
//     name: string;
//     capacity: number;
//     used: number;
//     products: ProductInRack[];
//   }
  
//   export interface ProductInRack {
//     id: string;
//     barcode: string;
//     name: string;
//     quantity: number;
//     rackId: string;
//     lastUpdated: string;
//   }
  
//   export interface StockOperation {
//     type: 'IN' | 'OUT' | 'DELETE';
//     productBarcode: string;
//     quantity: number;
//     rackId: string;
//     timestamp: string;
//     manualPercentage?: number;
//   }
  

export interface Rack {
  id: string;
  name: string;
  capacity: number;
  used: number;
  products: ProductInRack[];
}

export interface ProductInRack {
  id: string;
  barcode: string;
  name: string;
  quantity: number;
  rackId: string;
  lastUpdated: string;
}

export interface StockOperation {
  type: 'IN' | 'OUT' | 'DELETE';
  productBarcode: string;
  quantity: number;
  rackId: string;
  timestamp: string;
}
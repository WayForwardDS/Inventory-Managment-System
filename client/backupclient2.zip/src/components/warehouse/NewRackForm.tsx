import React from 'react';
import { Modal, Form, Input, Slider } from 'antd';

interface NewRackFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (values: { name: string; barcode: string; capacity: number }) => void;
}

export const NewRackForm = ({ open, onClose, onSubmit }: NewRackFormProps) => {
  const [form] = Form.useForm();

  const handleFinish = (values: any) => {
    onSubmit(values);
    form.resetFields();
  };

  return (
    <Modal
      title="Add New Rack"
      open={open}
      onCancel={onClose}
      onOk={() => form.submit()}
      okText="Create Rack"
    >
      <Form layout="vertical" form={form} onFinish={handleFinish}>
        <Form.Item
          label="Rack No"
          name="name"
          rules={[{ required: true, message: 'Please enter the Rack number!' }]}
        >
          <Input placeholder="e.g., Rack A1" />
        </Form.Item>

        <Form.Item
          label="Rack Barcode"
          name="barcode"
          rules={[{ required: true, message: 'Please enter the barcode!' }]}
        >
          <Input placeholder="Numeric barcode" />
        </Form.Item>

        <Form.Item label="Rack Space (Capacity)" name="capacity" initialValue={0}>
          <Slider
            marks={{ 0: '0%', 50: '50%', 100: '100%' }}
            min={0}
            max={100}
            step={50}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

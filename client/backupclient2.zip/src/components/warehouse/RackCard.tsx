// import { Card, Tag, Tooltip, Badge } from 'antd';
// import {
//   HomeOutlined,
//   InboxOutlined,
//   PercentageOutlined,
//   EditOutlined,
//   DeleteOutlined,
// } from '@ant-design/icons';
// import { motion } from 'framer-motion';
// import { TinyColor } from '@ctrl/tinycolor';
// import { Rack } from '../../types/warehouse.type';

// interface RackCardProps {
//   rack: Rack;
//   onClick: () => void;
//   onDelete: () => void;
// }

// export const RackCard = ({ rack, onClick }: RackCardProps) => {
//   const percentage = Math.round((rack.used / rack.capacity) * 100);
//   const statusColor =
//     percentage >= 100 ? '#ff4d4f' : percentage >= 90 ? '#faad14' : '#52c41a';
//   const animatedColor = new TinyColor(statusColor).lighten(8).toString();

//   function onDelete() {
//     throw new Error('Function not implemented.');
//   }

//   return (
//     <>
//     <motion.div
//       onClick={onClick}
//       className="cursor-pointer"
//       whileHover={{ scale: 1.05 }}
//       whileTap={{ scale: 0.98 }}
//       transition={{ type: 'spring', stiffness: 300, damping: 20 }}
//     >
//       <Card
//         bordered={false}
//         className="relative transition-all shadow-md w-72 h-60 rounded-2xl bg-white/90 backdrop-blur-lg hover:shadow-xl"
//       >
//         <div className="flex items-center justify-between mb-2">
//           <div className="flex items-center gap-2">
//             <HomeOutlined className="text-gray-500" />
//             <span className="text-sm font-semibold text-gray-700">{rack.name}</span>
//           </div>
//           <div className="flex items-center gap-2">
//   <Tooltip title="Edit Rack">
//     <EditOutlined className="text-sm text-blue-500 hover:text-blue-700" />
//   </Tooltip>
//   <Tooltip title="Delete Rack">
//     <DeleteOutlined
//       className="text-sm text-red-500 hover:text-red-700"
//       onClick={(e) => {
//         e.stopPropagation();
//         onDelete();
//       }}
//     />
//   </Tooltip>
// </div>
//         </div>

//         <motion.div
//           className="flex flex-col items-center justify-center mt-3"
//           initial={{ opacity: 0, y: 20 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.1 }}
//         >
//           <div
//             className="relative w-28 h-28 rounded-full border-[6px] flex items-center justify-center"
//             style={{ borderColor: animatedColor }}
//           >
            
//             <span className="text-xl font-bold text-gray-700">{percentage}%</span>
//           </div>
//           <span className="mt-1 text-xs text-gray-500">Rack Usage</span>
//         </motion.div>

//         <div className="absolute space-y-1 bottom-4 left-4">
//   <Tag
//     icon={<PercentageOutlined />}
//     color="blue"
//     className="text-xs px-2 py-0.5"
//   >
//     {rack.capacity} units
//   </Tag>
//   <Tag
//     color={percentage >= 100 ? 'red' : 'green'}
//     className="text-xs px-2 py-0.5"
//   >
//     {rack.used} stored
//   </Tag>
//   <Tag
//     icon={<InboxOutlined />}
//     color="geekblue"
//     className="text-xs px-2 py-0.5"
//   >
//     {rack.barcode}
//   </Tag>
// </div>


//         {percentage >= 100 && (
//           <Badge.Ribbon text="FULL" color="red" className="absolute -top-1 -right-1" />
//         )}
//       </Card>
//     </motion.div>
//     </>
//   );
// };

import React from 'react';
import { Card, Tag, Tooltip, Badge, Progress } from 'antd';
import { 
  HomeOutlined, 
  EditOutlined, 
  DeleteOutlined, 
  PercentageOutlined, 
  InboxOutlined,
  ExclamationCircleFilled 
} from '@ant-design/icons';
import { motion } from 'framer-motion';
import { Rack } from '../../types/warehouse.type';

interface RackCardProps {
  rack: Rack;
  onClick: () => void;
  onDelete: () => void;
}

export const RackCard = ({ rack, onClick, onDelete }: RackCardProps) => {
  const percentage = Math.round((rack.used / rack.capacity) * 100);
  const isFull = percentage >= 100;
  const isCritical = percentage >= 90 && !isFull;

  // Color scheme based on capacity
  const statusColors = {
    empty: '#52c41a',
    normal: '#1890ff',
    critical: '#faad14',
    full: '#ff4d4f'
  };

  const statusColor = isFull ? statusColors.full :
                     isCritical ? statusColors.critical :
                     percentage === 0 ? statusColors.empty : 
                     statusColors.normal;

  return (
    <motion.div
      onClick={onClick}
      className="cursor-pointer"
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <Card
        bordered={false}
        className={`relative transition-all shadow-md w-72 h-64 rounded-2xl bg-white/90 backdrop-blur-lg hover:shadow-xl ${
          isFull ? 'ring-2 ring-red-500' : ''
        }`}
      >
        {/* Full Rack Ribbon */}
        {isFull && (
          <Badge.Ribbon 
            text="FULL" 
            color="red"
            className="absolute font-bold -top-1 -right-1"
          />
        )}

        {/* Critical Warning */}
        {isCritical && (
          <div className="absolute text-yellow-500 top-2 right-2">
            <ExclamationCircleFilled className="text-xl" />
          </div>
        )}

        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <HomeOutlined className="text-gray-500" />
            <span className="text-sm font-semibold text-gray-700">{rack.name}</span>
          </div>
          <div className="flex items-center gap-2">
            <Tooltip title="Edit Rack">
              <EditOutlined 
                className="text-sm text-blue-500 hover:text-blue-700"
                onClick={(e) => e.stopPropagation()}
              />
            </Tooltip>
            <Tooltip title="Delete Rack">
              <DeleteOutlined
                className="text-sm text-red-500 hover:text-red-700"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete();
                }}
              />
            </Tooltip>
          </div>
        </div>

        {/* Circular Progress */}
        <div className="flex flex-col items-center justify-center mt-2">
          <Progress
            type="dashboard"
            percent={percentage}
            strokeColor={statusColor}
            strokeWidth={10}
            trailColor="#f0f0f0"
            format={() => (
              <div className="text-center">
                <span className="text-2xl font-bold">{percentage}%</span>
                <div className="mt-1 text-xs text-gray-500">Usage</div>
              </div>
            )}
            width={120}
          />
        </div>

        {/* Rack Stats */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-center justify-between mb-2">
            <Tag icon={<PercentageOutlined />} color="blue">
              Capacity: {rack.capacity}
            </Tag>
            <Tag color={isFull ? 'red' : 'green'}>
              Used: {rack.used}
            </Tag>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full">
            <div 
              className="h-2 rounded-full"
              style={{
                width: `${percentage}%`,
                backgroundColor: statusColor
              }}
            />
          </div>
        </div>

        {/* Barcode Tag */}
        {rack.barcode && (
          <div className="absolute top-4 left-4">
            <Tag icon={<InboxOutlined />} color="geekblue">
              {rack.barcode}
            </Tag>
          </div>
        )}
      </Card>
    </motion.div>
  );
};
// src/pages/warehouse/RackDisplay.tsx
import { useState } from 'react';
import { Button } from 'antd';
import { RackCard } from '../../components/warehouse/RackCard'; // Adjusted to import RackCard
import { AddStockForm } from '../../components/warehouse/AddStockForm';
import { Rack } from '../../types/warehouse.type';
import { useOutletContext } from 'react-router-dom';
import { NewRackForm } from '../../components/warehouse/NewRackForm'; // Ensure proper import

interface OutletContextType {
  racks: Rack[];
}

export const RackDisplay = () => {
  const { racks: contextRacks } = useOutletContext<OutletContextType>(); // Use racks from context
  const [racks, setRacks] = useState<Rack[]>(contextRacks); // Full racks passed from context
  const [selectedRack, setSelectedRack] = useState<Rack | null>(null);
  const [rackModalOpen, setRackModalOpen] = useState(false);

  const handleAddRack = (newRack: { name: string; barcode: string; capacity: number }) => {
    const createdRack: Rack = {
      id: Date.now().toString(),
      name: newRack.name,
      barcode: newRack.barcode,
      capacity: newRack.capacity,
      used: 0, // Initial usage can be set to 0
      products: [],
    };
    setRacks((prev) => [...prev, createdRack]);
    setRackModalOpen(false);
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Warehouse Rack Display</h2>
        <Button type="primary" onClick={() => setRackModalOpen(true)}>
          + Add New Rack
        </Button>
      </div>

      {/* Render Rack Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {racks.map((rack) => (
          <RackCard
            key={rack.id}
            rack={rack} // Pass the full Rack object to RackCard
            onClick={() => setSelectedRack(rack)}
            onDelete={() =>
              setRacks((prev) => prev.filter((r) => r.id !== rack.id)) // Handle rack deletion
            }
          />
        ))}
      </div>

      {/* Display Add Stock Form for selected Rack */}
      {selectedRack && (
        <AddStockForm
          rack={selectedRack}
          onClose={() => setSelectedRack(null)}
        />
      )}

      {/* New Rack Form Modal */}
      <NewRackForm
        open={rackModalOpen}
        onClose={() => setRackModalOpen(false)}
        onSubmit={handleAddRack}
      />
    </div>
  );
};

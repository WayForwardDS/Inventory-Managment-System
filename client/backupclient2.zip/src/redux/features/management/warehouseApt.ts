// import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
// import { Rack, ProductInRack, StockOperation } from '../../../types/warehouse.type';

// // Mock data
// let mockRacks: Rack[] = [
//   {
//     id: '1',
//     name: 'Rack A1',
//     capacity: 100,
//     used: 30,
//     products: [
//       { id: 'p1', barcode: '12345678', name: 'Product X', quantity: 10, rackId: '1', lastUpdated: new Date().toISOString() },
//       { id: 'p2', barcode: '87654321', name: 'Product Y', quantity: 20, rackId: '1', lastUpdated: new Date().toISOString() }
//     ]
//   },
//   {
//     id: '2',
//     name: 'Rack B2',
//     capacity: 100,
//     used: 80,
//     products: [
//       { id: 'p3', barcode: '11223344', name: 'Product Z', quantity: 80, rackId: '2', lastUpdated: new Date().toISOString() }
//     ]
//   },
//   {
//     id: '3',
//     name: 'Rack C3',
//     capacity: 100,
//     used: 100,
//     products: [
//       { id: 'p4', barcode: '55667788', name: 'Product W', quantity: 100, rackId: '3', lastUpdated: new Date().toISOString() }
//     ]
//   }
// ];

// let mockProducts: Record<string, ProductInRack> = {
//   '12345678': { id: 'p1', barcode: '12345678', name: 'Product X', quantity: 10, rackId: '1', lastUpdated: new Date().toISOString() },
//   '87654321': { id: 'p2', barcode: '87654321', name: 'Product Y', quantity: 20, rackId: '1', lastUpdated: new Date().toISOString() },
//   '11223344': { id: 'p3', barcode: '11223344', name: 'Product Z', quantity: 80, rackId: '2', lastUpdated: new Date().toISOString() },
//   '55667788': { id: 'p4', barcode: '55667788', name: 'Product W', quantity: 100, rackId: '3', lastUpdated: new Date().toISOString() }
// };

// export const warehouseApi = createApi({
//   reducerPath: 'warehouseApi',
//   baseQuery: fetchBaseQuery({
//     baseUrl: '/api/warehouse',
//     fetchFn: async (...args) => {
//       const [input] = args;
//       const url = typeof input === 'string' ? input : input.url;
//       const method = args[0]?.method || 'GET';

//       // --- Mock GET Racks ---
//       if (url.includes('/racks')) {
//         return { data: mockRacks };
//       }

//       // --- Mock GET Product by Barcode ---
//       if (url.includes('/stock/') && method === 'GET') {
//         const barcode = url.split('/stock/')[1];
//         const product = mockProducts[barcode];
//         return product ? { data: product } : { error: 'Product not found' };
//       }

//       // --- Mock Rack Capacity ---
//       if (url.includes('/rack/') && url.includes('/capacity')) {
//         const rackId = url.split('/rack/')[1].split('/capacity')[0];
//         const rack = mockRacks.find(r => r.id === rackId);
//         return rack ? {
//           data: {
//             used: rack.used,
//             available: rack.capacity - rack.used
//           }
//         } : { error: 'Rack not found' };
//       }

//       // --- Mock POST Stock Operation ---
//       if (url.includes('/stock') && method === 'POST') {
//         const operation = args[0]?.body as StockOperation;
//         console.log('Mock POST Stock Operation:', operation);
//         return { data: null };
//       }

//       // --- Mock DELETE Stock ---
//       if (url.includes('/stock/') && method === 'DELETE') {
//         const id = url.split('/stock/')[1];
//         console.log(`Mock DELETE stock with ID: ${id}`);

//         // Remove from mockProducts
//         delete mockProducts[id];

//         // Remove from racks
//         mockRacks = mockRacks.map(rack => ({
//           ...rack,
//           products: rack.products.filter(product => product.id !== id)
//         }));

//         return { data: null };
//       }

//       // Default to actual fetch if not handled
//       return fetch(...args);
//     },
//   }),
//   tagTypes: ['Racks', 'Stock'],
//   endpoints: (builder) => ({
//     getRacks: builder.query<Rack[], void>({
//       query: () => '/racks',
//       providesTags: ['Racks'],
//     }),
//     getStockByBarcode: builder.query<ProductInRack, string>({
//       query: (barcode) => `/stock/${barcode}`,
//       providesTags: (_result, _error, barcode) => [{ type: 'Stock', id: barcode }],
//     }),
//     getRackCapacity: builder.query<{ used: number; available: number }, string>({
//       query: (rackId) => `/rack/${rackId}/capacity`,
//     }),
//     updateStock: builder.mutation<void, StockOperation>({
//       query: (operation) => ({
//         url: '/stock',
//         method: 'POST',
//         body: operation,
//       }),
//       invalidatesTags: (_result, _error, operation) => [
//         'Racks',
//         { type: 'Stock', id: operation.productBarcode }
//       ],
//     }),
//     deleteStock: builder.mutation<void, string>({
//       query: (id) => ({
//         url: `/stock/${id}`,
//         method: 'DELETE',
//       }),
//       invalidatesTags: (_result, _error, id) => [
//         'Racks',
//         { type: 'Stock', id },
//       ],
//     }),
//   }),
// });

// export const {
//   useGetRacksQuery,
//   useGetStockByBarcodeQuery,
//   useGetRackCapacityQuery,
//   useUpdateStockMutation,
//   useDeleteStockMutation, // ✅ Now available
// } = warehouseApi;

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Rack, ProductInRack, StockOperation } from '../../../types/warehouse.type';

// Mock data
const mockRacks: Rack[] = [
  { 
    id: '1', 
    name: 'Rack A1', 
    capacity: 100, 
    used: 30,
    products: [
      { id: 'p1', barcode: '12345678', name: 'Product X', quantity: 10, rackId: '1', lastUpdated: new Date().toISOString() },
      { id: 'p2', barcode: '87654321', name: 'Product Y', quantity: 20, rackId: '1', lastUpdated: new Date().toISOString() }
    ]
  },
  { 
    id: '2', 
    name: 'Rack B2', 
    capacity: 100, 
    used: 80,
    products: [
      { id: 'p3', barcode: '11223344', name: 'Product Z', quantity: 80, rackId: '2', lastUpdated: new Date().toISOString() }
    ]
  },
  { 
    id: '3', 
    name: 'Rack C3', 
    capacity: 100, 
    used: 100,
    products: [
      { id: 'p4', barcode: '55667788', name: 'Product W', quantity: 100, rackId: '3', lastUpdated: new Date().toISOString() }
    ]
  }
];

const mockProducts: Record<string, ProductInRack> = {
  '12345678': { id: 'p1', barcode: '12345678', name: 'Product X', quantity: 10, rackId: '1', lastUpdated: new Date().toISOString() },
  '87654321': { id: 'p2', barcode: '87654321', name: 'Product Y', quantity: 20, rackId: '1', lastUpdated: new Date().toISOString() },
  '11223344': { id: 'p3', barcode: '11223344', name: 'Product Z', quantity: 80, rackId: '2', lastUpdated: new Date().toISOString() },
  '55667788': { id: 'p4', barcode: '55667788', name: 'Product W', quantity: 100, rackId: '3', lastUpdated: new Date().toISOString() }
};

export const warehouseApi = createApi({
  reducerPath: 'warehouseApi',
  baseQuery: fetchBaseQuery({ 
    baseUrl: '/api/warehouse',
    fetchFn: async (input: RequestInfo, init?: RequestInit) => {
      // Create a proper mock Response
      const createMockResponse = (data: any, status = 200) => {
        return new Response(JSON.stringify(data), {
          status,
          headers: {
            'Content-Type': 'application/json'
          }
        });
      };

      const url = typeof input === 'string' ? input : input.url;

      // Mock endpoints
      if (url.includes('/racks')) {
        return createMockResponse(mockRacks);
      }
      
      if (url.includes('/stock/')) {
        const barcode = url.split('/stock/')[1];
        const product = mockProducts[barcode];
        return product 
          ? createMockResponse(product)
          : createMockResponse({ error: 'Product not found' }, 404);
      }
      
      if (url.includes('/rack/') && url.includes('/capacity')) {
        const rackId = url.split('/rack/')[1].split('/capacity')[0];
        const rack = mockRacks.find(r => r.id === rackId);
        return rack 
          ? createMockResponse({ 
              used: rack.used, 
              available: rack.capacity - rack.used 
            })
          : createMockResponse({ error: 'Rack not found' }, 404);
      }
      
      if (url.includes('/stock') && init?.method === 'POST') {
        const operation = JSON.parse(init?.body as string) as StockOperation;
        console.log('Mock API: Would normally send:', operation);
        return createMockResponse({ success: true }, 200);
      }

      // Fallback to actual fetch
      return fetch(input, init);
    }
  }),
  tagTypes: ['Racks', 'Stock'],
  endpoints: (builder) => ({
    getRacks: builder.query<Rack[], void>({
      query: () => '/racks',
      providesTags: ['Racks'],
    }),
    getStockByBarcode: builder.query<ProductInRack, string>({
      query: (barcode) => `/stock/${barcode}`,
      providesTags: (_result, _error, barcode) => [{ type: 'Stock', id: barcode }],
    }),
    getRackCapacity: builder.query<{ used: number; available: number }, string>({
      query: (rackId) => `/rack/${rackId}/capacity`,
    }),
    updateStock: builder.mutation<void, StockOperation>({
      query: (operation) => ({
        url: '/stock',
        method: 'POST',
        body: operation,
      }),
      invalidatesTags: (_result, _error, operation) => [
        'Racks',
        { type: 'Stock', id: operation.productBarcode }
      ],
    }),
  }),
});

export const {
  useGetRacksQuery,
  useGetStockByBarcodeQuery,
  useGetRackCapacityQuery,
  useUpdateStockMutation,
} = warehouseApi;
import { Col, Row } from 'antd';

interface Props {
  name: string;
  id?: string;
  errors?: any;
  label: string;
  type?: string;
  register: any;
  required?: boolean;
  hidden?: boolean;
  readOnly?: boolean;
  defaultValue?: any; 
  className?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void; 
}

const CustomInput = ({
  name,
  errors = {},
  required = false,
  label,
  readOnly = false,
  hidden = false,
  onChange,
  register,
  type = 'text',
  id = "",
  className = ""
}: Props) => {
  return (
    <>
     {/* {(label !== 'Role') && */}
      <Row id={id}>
        <Col className={!readOnly ? '' : 'text-start'} xs={{ span: 23 }} lg={{ span: 6 }}>
          <label htmlFor={name} className='label'>
            {label}
          </label>
        </Col>
        <Col xs={{ span: 23 }} lg={{ span: 18 }}>
          <input
            id={name}
            type={type}
            hidden={hidden}
            readOnly={readOnly}
            placeholder={label}
            min={0}
            {...register(name, { required: required })}
            onChange={onChange}
            className={`${className} ${readOnly ? 'w-full outline-none text-base font-semibold' : 'input-field w-full px-4 py-3 text-white bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-400'} ${errors[name] ? 'input-field-error' : ''}`}
          />
          {errors[name] && <p className="text-red-500 text-sm">{errors[name]?.message}</p>}
        </Col>
      </Row>
      {/* } */}
    </>
  );
};

export default CustomInput;

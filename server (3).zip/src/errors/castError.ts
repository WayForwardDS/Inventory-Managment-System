const castError = () => {
  return { _id: 'Request ID is invalid!' };
};

export default castError;
